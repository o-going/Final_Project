const express = require('express');
const path = require('path');
const url = require('url');
const fs = require('fs');
const router = express.Router();

const mysql = require('mysql2/promise');
const { captureRejectionSymbol } = require('events');

let con;
async function init() {
  con = await mysql.createConnection({
    host: 'localhost',
    user: 'gayoung',
    password: 'qawsedrf4578!',
    database: 'final'
  });
}
init();

router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/login', async(req, res) => {
  let body = req.body;
  console.log(body);
  
  let user;

  try{
    let [users, fileds] = await con.query(`SELECT * FROM \`users\`WHERE email = '${body.email}' AND password = '${body.password}'`);
    console.log('확인');
    console.log(users);
    if(users.length > 0) {
      user = users[0];
    }
    if(user == null) {
      res.send('<script type="text/javascript">alert("잘못된 email 혹은 비밀번호입니다.");location.href="/login";</script>');
      return;
    }
    else{
      console.log(user);
      req.session._id = user.id;
      req.session.email = user.email;
      req.session.name = user.name;
      res.send('<script type="text/javascript"> location.href = "/" </script>');
      return;
    }
  }catch (err){
    console.log(err);
    res.send('<script type="text/javascript">alert("Server Error");location.href="/login";</script>');
    return;
  }
});

router.get('/signup', (req, res) => {
  res.render('signup');
});

router.post('/signup', async(req, res) => {
  let body = req.body;
  console.log(body);
  try{
    let query = `INSERT INTO \`users\` (\`name\`, \`email\`, \`password\`) VALUES('${body.name}', '${body.email}', '${body.password}')`;
    let query2 = "INSERT INTO `users` (`name`, `email`, `password`) VALUES ('" + body.name + "', '" + body.email + "', '" + body.password + "')";

    await con.query(query);
  }catch(err) {
    console.log(err);
    res.send('<script type="text/javascript">alert("회원가입에 실패하셨습니다.");location.href="/signup";</script>');
    return;
  }
  res.send('<script type="text/javascript">alert("회원가입에 성공하셨습니다.");location.href="/login";</script>');
});

router.get('/techtree', (req, res) => {
  res.render('techtree');
});

router.get('/recommend', (req, res) => {
  res.render('recommend');
});

router.get('/require/:id', async (req, res) => {
  var id = req.params.id   // /require/1
  // var id = req.query.id // /require?id=1
  let position = req.params.position
  // let reqire = req.params.requirement
  // let preference = req.params.preference
  try{
    let positionInfo = await con.query('SELECT `positionId`, `position`,`position_Info`,`requirement`,`preference` FROM final.positions WHERE positionId='+id);
    //console.log(positionInfo[0][0]);
    let info = Object(positionInfo[0][0])
    console.log(info)
    let position = info.position_Info
    let buff = Buffer.from(position, 'base64')
    let text = buff.toString('utf-8')
    positionInfo[0][0].position_Info = text
    let req = info.requirement
     let buff1 = Buffer.from(req, 'base64')
     let text1 = buff1.toString('utf-8')
     positionInfo[0][0].requirement = text1
    //console.log(req)
    //let pre = info.preference
    // let buff2 = new Buffer.from(pre, 'base64')
    // let text2 = buff2.toString('utf-8')
    
    // console.log(text)
    // console.log(text1)
    // console.log(text2)
    // console.log("done")
    res.render('require', {
      id : req.params.id ,
      position_info: positionInfo[0][0], 
      //position_req: req, 
      // position_pre: pre
    });

  }catch(err) {

  }
});

router.get('/wanted', (req, res) => {
  res.render('wanted');
});

router.get('/', async (req, res) => {
  let body = req.body;
  console.log(body);
  
  try{
    // var[logos, column] = await con.query ( 'SELECT `companyId`,`logo_src` FROM final.companies' );
    var query = "SELECT "
        query += "positions.position,companies.logo_src,companies.company,positions.positionId "
        query += "from companies JOIN positions ON companies.companyId = positions.companyId order by rand() LIMIT 10"
    var random = await con.query(query);
    
    // console.log(random)
    // let companyRandom = logos
    // console.log(companyRandom)
    res.render('main.ejs', {
      companyName : random[0],
      companyRandom: random[0],
      companyPosition: random[0]
    });
    
    //console.log(column)
  }catch(err) {
    console.log(err)
  }
});

module.exports = router;